#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "156c7ba03f"  # abbreviated commit hash
commit = "156c7ba03f40441c3940cf79cef7fcbf4f719612"  # commit hash
date = "2022-08-07 19:10:09 +0100"  # commit date
author = "Efrem Braun <efrem.braun@gmail.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Include information about libc++ files being included in the bundle in the docs"""
